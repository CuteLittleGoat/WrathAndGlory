W tym folderze nie twórz i nie aktualizuj automatycznie plików README i Documentation bez wyraźniego polecenia użytkownika.
